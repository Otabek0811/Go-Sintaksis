package main

import "fmt"

func main() {
	var a int =5

	fmt.Println("Perimetr: ",4*a,"\nYuza: ",a*a)
}
