package main

import "fmt"

func main(){
	var n int = 43

	if n%2==0{
		fmt.Println(n)
	}else{
		fmt.Println(n*2)
	}
}