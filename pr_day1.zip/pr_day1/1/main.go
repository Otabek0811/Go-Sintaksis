package main

import "fmt"

func main(){
	var Selsiy uint8 = 23
	
	fmt.Println("Kelvin: ",float32(Selsiy)+273.15, "\nFahrenheit: ",float32(Selsiy)*1.8+32)
}